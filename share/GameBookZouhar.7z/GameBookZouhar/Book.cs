﻿using System;
using System.Collections.Generic;
namespace GameBookZouhar
{
    public class Book
    {
		public List<Page> pages;
        public Book()
        {
            pages = new List<Page>();
        }
    }
}
