﻿using Snake.Input;
using Snake.MapRelated;
using Snake.Utils;
using System;
using System.Collections.Generic;
using System.Text;

namespace Snake
{
    class Game
    {
        TimeDelta delta;
        GameMap map;

        public void Update()
        {
            throw new NotImplementedException();
        }
    }
}
