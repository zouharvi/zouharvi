﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Snake.Utils
{
    class TimeDelta
    {
        // TODO: missing constructor

        public void Update()
        {
            throw new NotImplementedException();
        }

        public long Last()
        {
            throw new NotImplementedException();
        }

        public long Current()
        {
            throw new NotImplementedException();
        }

        public long RealCurrent()
        {
            throw new NotImplementedException();
        }

        public long Delta()
        {
            throw new NotImplementedException();
        }

        public long DeltaTime()
        {
            throw new NotImplementedException();
        }
    }
}
