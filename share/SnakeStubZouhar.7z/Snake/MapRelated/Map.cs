﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Snake.MapRelated
{
    class Map
    {
        // TODO: missing constructor, local variables

        public IMapTile GetTile(int x, int y)
        {
            throw new NotImplementedException();
        }

        public void SetTile(IMapTile tile, int x, int y)
        {
            throw new NotImplementedException();
        }
    }
}
