﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Snake.Input
{
    class KeyboardController : IPlayerController
    {
        public Direction GetInput()
        {
            throw new NotImplementedException();
        }

        public bool IsEndGame()
        {
            throw new NotImplementedException();
        }

        public void Reverse(long milis)
        {
            throw new NotImplementedException();
        }

        public void Update()
        {
            throw new NotImplementedException();
        }
    }
}
