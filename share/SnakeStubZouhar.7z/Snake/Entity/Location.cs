﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Snake.Entity
{
    class Location
    {
        public int GetX()
        {
            throw new NotImplementedException();
        }

        public int GetY()
        {
            throw new NotImplementedException();
        }
    }
}
