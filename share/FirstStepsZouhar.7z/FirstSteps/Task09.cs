﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FirstSteps
{
    class Task09
    {
        /// <summary>
        /// Display the sum of all even numbers between 0 and 100.
        /// </summary>
        public static void Run()
        {
            // N*(N+1)/2
            Console.WriteLine(100 * 101 / 2); // maths
        }
    }
}
